# 전통을 지키자.
print("Hello, World!")
